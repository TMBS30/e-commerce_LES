package controle;

import java.io.IOException;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import dao.*;
import dominio.*;
import implementacao.IStrategy;
import implementacao.ValidarLogin;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpSession;
import util.Conexao;

@WebServlet("/servlet")
public class CtrlServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        System.out.println("Action recebida: " + action);
        String id = request.getParameter("id");
        System.out.println("ID recebido: " + id);


        if (action == null || action.isEmpty()) {
            action = "home";
        }

        switch (action) {
            case "consultar":
                consultarCliente(request, response);
                break;
            case "home":
                homePage(request, response);
                break;
            case "voltarHomePage":
                voltarHomePage(request, response);
                break;
            case "consultarInfoPessoais":
                consultarInfoPessoais(request, response);
                break;
            case "consultarEndereco":
                consultarEnderecoPessoal(request, response);
                break;
            case "cadastro":
                cadastrarCliente(request, response);
                break;
            case "consultarCartao":
                consultarCartaoPessoal(request, response);
                break;
            case "editarCartaoForm":
                editarCartaoForm(request, response);
                System.out.println("Em GET editarCartaoForm");
                break;
            case "consultarProduto":
                consultarProduto(request, response);
                break;
           /* case "consultarCartao":
                consultarCartao(request, response);
                break;
            case "consultarEndereco":
                consultarEndereco(request, response);
                break;*/

            case "addcliente":
                System.out.println("Redirecionando para addClienteForm.jsp");
                request.getRequestDispatcher("addClienteForm.jsp").forward(request, response);
                return;
            default:
                System.out.println("Ação desconhecida: " + action);
                break;
        }

        EstadoDAO estadoDAO = new EstadoDAO();
        List<Estado> estados = estadoDAO.consultar();

        CidadeDAO cidadeDAO = new CidadeDAO();
        List<Cidade> cidades = cidadeDAO.consultar();

        PaisDAO paisDAO = new PaisDAO();
        List<Pais> paises = paisDAO.consultar();

        TipoEnderecoDAO tipoEnderecoDAO = new TipoEnderecoDAO();
        List<TipoEndereco> tipoEnderecos = tipoEnderecoDAO.consultar();

        TipoLogradouroDAO tipoLogradouroDAO = new TipoLogradouroDAO();
        List<TipoLogradouro> tipoLogradouros = tipoLogradouroDAO.consultar();

        TipoResidenciaDAO tipoResidenciaDAO = new TipoResidenciaDAO();
        List<TipoResidencia> tipoResidencias = tipoResidenciaDAO.consultar();

        TipoTelefoneDAO tipoTelefoneDAO = new TipoTelefoneDAO();
        List<TipoTelefone> tipoTelefones = tipoTelefoneDAO.consultar();

        BandeiraCartaoDAO bandeiraCartaoDAO = new BandeiraCartaoDAO();
        List<BandeiraCartao> bandeiraCartaoLista = bandeiraCartaoDAO.consultar();

        System.out.println("Bandeiras retornados: " + bandeiraCartaoLista);
        request.setAttribute("listaBandeiras", bandeiraCartaoLista);

        System.out.println("Estados retornados: " + estados);
        request.setAttribute("listaEstados", estados);

        System.out.println("Cidades retornados: " + cidades);
        request.setAttribute("listaCidades", cidades);

        System.out.println("Paises retornados: " + paises);
        request.setAttribute("listaPaises", paises);

        System.out.println("Tipos Enderecos retornados: " + tipoEnderecos);
        request.setAttribute("listaTiposEnd", tipoEnderecos);

        System.out.println("Tipos Logradouros retornados: " + tipoLogradouros);
        request.setAttribute("listaTiposLog", tipoLogradouros);

        System.out.println("Tipos Residencias retornados: " + tipoResidencias);
        request.setAttribute("listaTiposRes", tipoResidencias);

        System.out.println("Tipos Telefones retornados: " + tipoTelefones);
        request.setAttribute("listaTiposTel", tipoTelefones);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String action = request.getParameter("action");

        if (action == null || action.isEmpty()) {
            action = "salvarCliente";
        }

        switch (action) {
            case "login":
                loginAction(request, response);
                return;
            case "salvarCliente":
                try {
                    salvarCliente(request, response);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
                break;
            case "salvarEndereco":
                salvarEndereco(request, response);
                break;
            case "salvarNovoEnderecoForm":
                salvarNovoEnderecoForm(request, response);
                break;
            case "salvarNovoEndereco":
                salvarNovoEndereco(request, response);
                break;
            case "salvarNovoCartaoForm":
                salvarNovoCartaoForm(request, response);
                break;
            case "salvarNovoCartao":
                salvarNovoCartao(request, response);
                break;
            case "excluirCartao":
                excluirCartao(request, response);
                break;
            case "editarCartao":
                editarCartao(request, response);
                break;
            case "adicionarCarrinho":
                adicionarCarrinho(request, response);
                break;
            case "removerItemCarrinho":
                removerItemCarrinho(request, response);
                break;
            case "salvarPreviaPedido":
                salvarPreviaPedido(request, response);
                break;

            default:
                request.setAttribute("mensagemErro", "Ação não reconhecida.");
                request.getRequestDispatcher("index.jsp").forward(request, response);
                return;
        }
    }

    private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null) {
            response.sendRedirect("index.jsp");
            return;
        }
        switch (action) {
            case "cadastro":
                cadastrarCliente(request, response);
                break;
            case "consultar":
                consultarCliente(request, response);
                break;
            case "excluir":
                excluirCliente(request, response);
                break;
            default:
                response.sendRedirect("erro.jsp");
        }
    }

    //COM CRIPTOGRAFIA
    private void loginAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email_login");
        String senha = request.getParameter("senha_login");

        Cliente cliente = new Cliente();
        cliente.setEmail(email);
        cliente.setSenha(senha);

        ClienteDAO clienteDAO = new ClienteDAO();
        IStrategy validarLogin = new ValidarLogin();
        String resultado = validarLogin.processar(cliente);

        if (resultado.isEmpty()) {

            String senhaCriptografada = clienteDAO.senhaCriptografada(senha);

            Cliente clienteConsultado = clienteDAO.consultarPorEmailESenha(email, senhaCriptografada);

            if (clienteConsultado != null) {
                request.getSession().setAttribute("clienteId", clienteConsultado.getId());
                System.out.println("sucesso no login");

                homePage(request, response);

                request.getRequestDispatcher("home.jsp").forward(request, response);
            } else {
                request.setAttribute("mensagemErro", "Usuário ou senha inválidos.");
                System.out.println("falha no login");
                request.getRequestDispatcher("index.jsp").forward(request, response);
            }
        } else {
            request.setAttribute("mensagemErro", resultado);
            System.out.println("ERRO NO LOGIN");
            request.getRequestDispatcher("index.jsp").forward(request, response);
        }
    }
    //SEM CRIPTOGRAFIA
    /*private void loginAction(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email_login");
        String senha = request.getParameter("senha_login");

        Cliente cliente = new Cliente();
        cliente.setEmail(email);
        cliente.setSenha(senha);


        ClienteDAO clienteDAO = new ClienteDAO();
        // Validação de login (verificando email e senha)
        IStrategy validarLogin = new ValidarLogin();
        String resultado = validarLogin.processar(cliente);

        if (resultado.isEmpty()) {
            // Consultar no banco se o email e senha correspondem
            Cliente clienteConsultado = clienteDAO.consultarPorEmailESenha(email, senha);
            if (clienteConsultado != null) {

                request.getSession().setAttribute("clienteId", clienteConsultado.getId());
                System.out.println("sucesso no login");
                request.getRequestDispatcher("home.jsp").forward(request, response);
            } else {
                request.setAttribute("mensagemErro", "Usuário ou senha inválidos.");
                System.out.println("falha no login");
                request.getRequestDispatcher("index.jsp").forward(request, response);
            }
        } else {
            // Se houver erro de validação
            request.setAttribute("mensagemErro", resultado);
            System.out.println("ERRO NO LOGIN");
            request.getRequestDispatcher("index.jsp").forward(request, response);
        }
    }*/

    private void homePage(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        LivroDAO livroDAO = new LivroDAO();
        List<Livro> livros = livroDAO.consultarTodos();
        request.setAttribute("livros", livros);
    }


    private void voltarHomePage(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        LivroDAO livroDAO = new LivroDAO();
        List<Livro> livros = livroDAO.consultarTodos();
        request.setAttribute("livros", livros);
        request.getRequestDispatcher("home.jsp").forward(request, response);
    }


    private void consultarInfoPessoais(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("consultarInfoPessoais.jsp").forward(request, response);
    }

    private void consultarEnderecoPessoal(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("consultarEndereco.jsp").forward(request, response);
    }

    private void consultarCartaoPessoal(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("consultarCartao.jsp").forward(request, response);
    }

    private void editarCartaoForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("No metodo editarCartaoForm");
        request.getRequestDispatcher("editarCartao.jsp").forward(request, response);
    }

    private void editarCartao(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String idCartaoParam = request.getParameter("idCartao");
            System.out.println("\nID do Cartão para Editar (via parâmetro): " + idCartaoParam + "\n");

            if (idCartaoParam == null) {
                throw new ServletException("ID do cartão não encontrado.");
            }

            int idCartao = 0;
            try {
                idCartao = Integer.parseInt(idCartaoParam);
            } catch (NumberFormatException e) {
                throw new ServletException("Formato inválido para o ID do cartão.", e);
            }

            // Recuperando o cartão a ser editado
            CartaoDAO cartaoDAO = new CartaoDAO();
            Cartao cartao = cartaoDAO.consultarCartaoPorId(idCartao);
            if (cartao == null) {
                throw new ServletException("Cartão não encontrado.");
            }

            // Recuperando os dados do formulário
            String nomeTitular = request.getParameter("nomeTitular_editarCartao");
            System.out.println("nomeTitular: " + nomeTitular);
            String numeroCartao = request.getParameter("numeroCartao_editarCartao");
            System.out.println("numeroCartao: " + numeroCartao);
            String codSeguranca = request.getParameter("codSeguranca_editarCartao");
            System.out.println("codSeguranca: " + codSeguranca);
            String dataVencimento = request.getParameter("dataVencimento_editarCartao");
            System.out.println("dataVencimento: " + dataVencimento);
            String bandeiraCartao = request.getParameter("bandeira_editarCartao");
            System.out.println("bandeira: " + bandeiraCartao);
            String preferencialCartao = request.getParameter("preferencialCartao_editarCartao");
            System.out.println("preferencialCartao: " + preferencialCartao);

            boolean preferencial = "true".equals(preferencialCartao);

            // Atualizando os valores do cartão
            cartao.setNomeTitular(nomeTitular);
            cartao.setNumero(numeroCartao);
            cartao.setCodSeguranca(codSeguranca);
            cartao.setDataVencimento(dataVencimento);
            cartao.setPreferencial(preferencial);
            cartao.setBandeiraCartao(BandeiraCartao.fromDescricao(bandeiraCartao));

            // Usando a fachada para chamar o método de alteração
            IFachada fachada = new Fachada();
            System.out.println("ID do cliente armazenado na sessão: " + cartao.getIdCliente());
            String msgCartaoEditado = fachada.alterarCartao(cartao);
            System.out.println("Resultado da edição do cartão: " + msgCartaoEditado);

            // Redirecionando para a página de consulta ou outra página de sucesso
            request.getRequestDispatcher("consultarCartao.jsp").forward(request, response);

        } catch (Exception e) {
            throw new ServletException("Erro ao editar cartão", e);
        }
    }

    private void salvarNovoCartaoForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("adicionarNovoCartao.jsp").forward(request, response);
    }

    private void salvarNovoCartao(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String idClienteParam = request.getParameter("idCliente");
            System.out.println("\nId do Cliente para Novo Endereco (via parâmetro): " + idClienteParam + "\n");

            HttpSession session = request.getSession(false);
            if (session != null) {
                // Recuperando o ID do cliente
                Integer clienteId = (Integer) session.getAttribute("clienteId");
                if (clienteId != null) {
                    System.out.println("ID do cliente recuperado da sessão: " + clienteId);
                } else {
                    System.out.println("ID do cliente não encontrado na sessão.");
                }
            } else {
                System.out.println("Sessão não encontrada.");
            }

            if (idClienteParam == null) {
                throw new ServletException("ID do cliente não encontrado.");
            }

            int idCliente = 0;
            try {
                idCliente = Integer.parseInt(idClienteParam);
            } catch (NumberFormatException e) {
                throw new ServletException("Formato inválido para o ID do cliente.", e);
            }

            ClienteDAO clienteDAO = new ClienteDAO();
            Cliente cliente = clienteDAO.consultarPorId(idCliente);
            if (cliente == null) {
                throw new ServletException("Cliente não encontrado.");
            }
            cliente.setId(idCliente);

            //CODIGO DO CARTAO
            String nomeTitular = request.getParameter("nomeTitular_novoCartao");
            System.out.println("nomeTitular: " + nomeTitular);
            String numeroCartao = request.getParameter("numeroCartao_novoCartao");
            System.out.println("numeroCartao: " + numeroCartao);
            String codSeguranca = request.getParameter("codSeguranca_novoCartao");
            System.out.println("codSeguranca: " + codSeguranca);
            String dataVencimento = request.getParameter("dataVencimento_novoCartao");
            System.out.println("dataVencimento: " + dataVencimento);
            String bandeiraCartao = request.getParameter("bandeira_novoCartao");
            System.out.println("bandeira: " + bandeiraCartao);
            String preferencialCartao = request.getParameter("preferencialCartao_novoCartao");
            System.out.println("preferencialCartao: " + preferencialCartao);

            boolean preferencial = "true".equals(preferencialCartao);

            Cartao cartaoSalvar = new Cartao();
            cartaoSalvar.setNomeTitular(nomeTitular);
            cartaoSalvar.setNumero(numeroCartao);
            cartaoSalvar.setCodSeguranca(codSeguranca);
            cartaoSalvar.setDataVencimento(dataVencimento);
            cartaoSalvar.setPreferencial(preferencial);
            cartaoSalvar.setBandeiraCartao(BandeiraCartao.fromDescricao(bandeiraCartao));

            IFachada fachada = new Fachada();
            System.out.println("03 idCliente armazenado na sessão: " + cliente.getId());
            String msgNovoCartao = fachada.salvarCartao(cartaoSalvar);
            System.out.println("04 idCliente armazenado na sessão: " + cliente.getId());
            System.out.println("Resultado do salvar (Res): " + msgNovoCartao);


            request.getRequestDispatcher("consultarCartao.jsp").forward(request, response);

        } catch (Exception e) {
            throw new ServletException("Erro ao salvar cartao", e);
        }
    }


    // Método de exclusão de cartão
    private void excluirCartao(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int cartaoId = Integer.parseInt(request.getParameter("id"));
            System.out.println("ID recebido para exclusão: " + cartaoId);

            Cartao cartao = new Cartao();
            cartao.setId(cartaoId);

            // Chame a fachada para excluir
            IFachada fachada = new Fachada();
            String resultado = fachada.excluir(cartao);

            if (resultado == null) {
                System.out.println("Exclusão realizada com sucesso.");
                request.getSession().setAttribute("mensagemSucesso", "Cartão excluído com sucesso.");
            } else {
                System.out.println("Erro ao excluir: " + resultado);
                request.getSession().setAttribute("mensagemErro", resultado);
            }
        } catch (Exception e) {
            request.getSession().setAttribute("mensagemErro", "Falha ao excluir o cartão.");
        }

        response.sendRedirect("consultarCartao.jsp");
    }

    private void cadastrarCliente(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("addClienteForm.jsp").forward(request, response);
    }

    private void consultarCliente(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("consultaCliente.jsp").forward(request, response);
    }

    private void salvarCliente(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String nome = request.getParameter("nome_cadastro");
        String cpf = request.getParameter("cpf_cadastro");
        String email = request.getParameter("email_cadastro");
        String senha = request.getParameter("senha_cadastro");
        String confirmarSenha = request.getParameter("confirmarSenha_cadastro");
        String generoCli = request.getParameter("genero_cadastro");
        String dataNascimento = request.getParameter("dataNascimento_cadastro");
        String tipoTel = request.getParameter("tipoTel_cadastro");
        String ddd = request.getParameter("ddd_cadastro");
        String numero = request.getParameter("numero_cadastro");
        TipoTelefone tipoTelefone;

        if (tipoTel != null && !tipoTel.isEmpty()) {
            try {
                tipoTelefone = TipoTelefone.fromDescricao(tipoTel);
            } catch (IllegalArgumentException e) {
                throw new ServletException("Tipo de telefone inválido: " + tipoTel, e);
            }
        } else {
            throw new ServletException("Tipo de telefone não informado.");
        }

        Genero genero = Genero.fromDescricao(generoCli);

        if (ddd == null || ddd.isEmpty() || numero == null || numero.isEmpty()) {
            throw new ServletException("DDD e número de telefone são obrigatórios.");
        }

        Telefone telefone = new Telefone();
        telefone.setNumero(numero);
        telefone.setDdd(ddd);
        telefone.setTipo(tipoTelefone);

        //Cliente
        Cliente cliente = new Cliente();
        cliente.setNome(nome);
        cliente.setCpf(cpf);
        cliente.setEmail(email);
        cliente.setSenha(senha);
        cliente.setConfirmarSenha(confirmarSenha);
        cliente.setGenero(genero);
        cliente.setDataNascimento(dataNascimento);
        cliente.setTelefone(telefone);

        IFachada fachada = new Fachada();
        String msg = fachada.salvar(cliente);
        System.out.println("Resultado do salvar: " + msg);
        request.getSession().setAttribute("idCliente", cliente.getId());
        System.out.println("idCliente armazenado na sessão: " + cliente.getId());
        response.sendRedirect("cadastroClienteEndereco.jsp?idCliente=" + cliente.getId());
    }

    private void salvarEndereco(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        try {
            String idClienteParam = request.getParameter("idCliente");
            System.out.println("\nId do Cliente para Endereco: " + idClienteParam + "\n");

            if (idClienteParam == null || idClienteParam.isEmpty()) {
                throw new ServletException("ID do cliente não encontrado.");
            }

            int idCliente = 0;
            try {
                idCliente = Integer.parseInt(idClienteParam);
            } catch (NumberFormatException e) {
                throw new ServletException("Formato inválido para o ID do cliente.", e);
            }

            Cliente cliente = new Cliente();
            cliente.setId(idCliente);

            //RESIDENCIAL
            String nomePaisRes = request.getParameter("nomePaisRes_cadastro");
            System.out.println("SERVnomePaisRes: " + nomePaisRes);
            String nomeEstadoRes = request.getParameter("nomeEstadoRes_cadastro");
            System.out.println("nomeEstadoRes: " + nomeEstadoRes);
            String nomeCidadeRes = request.getParameter("nomeCidadeRes_cadastro");
            System.out.println("nomeCidadeRes: " + nomeCidadeRes);
            String tipoLogradouroRes = request.getParameter("tipoLogradouroRes_cadastro");
            System.out.println("tipoLogradouroRes: " + tipoLogradouroRes);
            String tipoResidenciaRes = request.getParameter("tipoResidenciaRes_cadastro");
            System.out.println("tipoResidenciaRes: " + tipoResidenciaRes);
            String cepRes = request.getParameter("cepRes_cadastro");
            System.out.println("cepRes: " + cepRes);
            String logradouroRes = request.getParameter("logradouroRes_cadastro");
            System.out.println("logradouroRes: " + logradouroRes);
            String numeroRes = request.getParameter("numeroRes_cadastro");
            System.out.println("numeroRes: " + numeroRes);
            String bairroRes = request.getParameter("bairroRes_cadastro");
            System.out.println("bairroRes: " + bairroRes);
            String observacaoRes = request.getParameter("observacaoRes_cadastro");
            System.out.println("SERVobservacaoRes: " + observacaoRes);

            Endereco enderecoRes = new Endereco();
            enderecoRes.setLogradouro(logradouroRes);
            enderecoRes.setNumero(numeroRes);
            enderecoRes.setBairro(bairroRes);
            enderecoRes.setCep(cepRes);
            enderecoRes.setObservacao(observacaoRes);
            if (tipoResidenciaRes == null || tipoResidenciaRes.isEmpty()) {
                throw new IllegalArgumentException("Nenhum tipo de residência selecionado.");
            } else {
                enderecoRes.setTipoResidencia(TipoResidencia.fromDescricao(tipoResidenciaRes));
            }
            enderecoRes.setTipoLogradouro(TipoLogradouro.fromDescricao(tipoLogradouroRes));

            Pais paisRes = new Pais();
            paisRes.setNome(nomePaisRes);

            Estado estadoRes = new Estado();
            estadoRes.setNome(nomeEstadoRes);
            estadoRes.setPais(paisRes);

            Cidade cidadeRes = new Cidade();
            cidadeRes.setNome(nomeCidadeRes);
            cidadeRes.setEstado(estadoRes);
            enderecoRes.setCidade(cidadeRes);

            //COBRANCA
            String nomePaisCob = request.getParameter("nomePaisCob_cadastro");
            System.out.println("SERVnomePaisCob: " + nomePaisCob);
            String nomeEstadoCob = request.getParameter("nomeEstadoCob_cadastro");
            System.out.println("nomeEstadoCob: " + nomeEstadoCob);
            String nomeCidadeCob = request.getParameter("nomeCidadeCob_cadastro");
            System.out.println("nomeCidadeCob: " + nomeCidadeCob);
            String tipoLogradouroCob = request.getParameter("tipoLogradouroCob_cadastro");
            System.out.println("tipoLogradouroCob: " + tipoLogradouroCob);
            String tipoResidenciaCob = request.getParameter("tipoResidenciaCob_cadastro");
            System.out.println("tipoResidenciaCob: " + tipoResidenciaCob);
            String cepCob = request.getParameter("cepCob_cadastro");
            System.out.println("cepCob: " + cepCob);
            String logradouroCob = request.getParameter("logradouroCob_cadastro");
            System.out.println("logradouroCob: " + logradouroCob);
            String numeroCob = request.getParameter("numeroCob_cadastro");
            System.out.println("numeroCob: " + numeroCob);
            String bairroCob = request.getParameter("bairroCob_cadastro");
            System.out.println("bairroCob: " + bairroCob);
            String observacaoCob = request.getParameter("observacaoCob_cadastro");
            System.out.println("SERVobservacaoCob: " + observacaoCob);

            Endereco enderecoCob = new Endereco();
            enderecoCob.setLogradouro(logradouroCob);
            enderecoCob.setNumero(numeroCob);
            enderecoCob.setBairro(bairroCob);
            enderecoCob.setCep(cepCob);
            enderecoCob.setObservacao(observacaoCob);
            enderecoCob.setTipoResidencia(TipoResidencia.fromDescricao(tipoResidenciaCob));
            enderecoCob.setTipoLogradouro(TipoLogradouro.fromDescricao(tipoLogradouroCob));

            Pais paisCob = new Pais();
            paisCob.setNome(nomePaisCob);

            Estado estadoCob = new Estado();
            estadoCob.setNome(nomeEstadoCob);
            estadoCob.setPais(paisCob);

            Cidade cidadeCob = new Cidade();
            cidadeCob.setNome(nomeCidadeCob);
            cidadeCob.setEstado(estadoCob);
            enderecoCob.setCidade(cidadeCob);

            //ENTREGA
            String nomePaisEnt = request.getParameter("nomePaisEnt_cadastro");
            System.out.println("SERVnomePaisEnt: " + nomePaisEnt);
            String nomeEstadoEnt = request.getParameter("nomeEstadoEnt_cadastro");
            System.out.println("SERVnomeEstadoEnt: " + nomeEstadoEnt);
            String nomeCidadeEnt = request.getParameter("nomeCidadeEnt_cadastro");
            System.out.println("SERVnomeCidadeEnt: " + nomeCidadeEnt);
            String tipoLogradouroEnt = request.getParameter("tipoLogradouroEnt_cadastro");
            System.out.println("tipoLogradouroEnt: " + tipoLogradouroEnt);
            String tipoResidenciaEnt = request.getParameter("tipoResidenciaEnt_cadastro");
            System.out.println("tipoResidenciaEnt: " + tipoResidenciaEnt);
            String cepEnt = request.getParameter("cepEnt_cadastro");
            System.out.println("cepEnt: " + cepEnt);
            String logradouroEnt = request.getParameter("logradouroEnt_cadastro");
            System.out.println("logradouroEnt: " + logradouroEnt);
            String numeroEnt = request.getParameter("numeroEnt_cadastro");
            System.out.println("numeroEnt: " + numeroEnt);
            String bairroEnt = request.getParameter("bairroEnt_cadastro");
            System.out.println("bairroEnt: " + bairroEnt);
            String observacaoEnt = request.getParameter("observacaoEnt_cadastro");
            System.out.println("SERVobservacaoEnt: " + observacaoEnt);

            Pais paisEnt = new Pais();
            paisEnt.setNome(nomePaisEnt);

            Estado estadoEnt = new Estado();
            estadoEnt.setNome(nomeEstadoEnt);
            estadoEnt.setPais(paisEnt);

            Cidade cidadeEnt = new Cidade();
            cidadeEnt.setNome(nomeCidadeEnt);
            cidadeEnt.setEstado(estadoEnt);

            Endereco enderecoEnt = new Endereco();
            enderecoEnt.setLogradouro(logradouroEnt);
            enderecoEnt.setNumero(numeroEnt);
            enderecoEnt.setBairro(bairroEnt);
            enderecoEnt.setCep(cepEnt);
            enderecoEnt.setCidade(cidadeEnt);
            enderecoEnt.setObservacao(observacaoEnt);
            enderecoEnt.setTipoResidencia(TipoResidencia.fromDescricao(tipoResidenciaEnt));
            enderecoEnt.setTipoLogradouro(TipoLogradouro.fromDescricao(tipoLogradouroEnt));

            String tipoEnderecoEnt = request.getParameter("tipoEnderecoEnt");
            System.out.println("SERVtipoEnderecoEnt: " + tipoEnderecoEnt);
            String tipoEnderecoCob = request.getParameter("tipoEnderecoCob");
            System.out.println("SERVtipoEnderecoCob: " + tipoEnderecoCob);
            String tipoEnderecoRes = request.getParameter("tipoEnderecoRes");
            System.out.println("SERVtipoEnderecoRes: " + tipoEnderecoRes);

            if (tipoEnderecoRes != null && !tipoEnderecoRes.isEmpty()) {
                enderecoRes.setTipoEndereco(TipoEndereco.fromDescricao(tipoEnderecoRes));
            }

            if (tipoEnderecoCob != null && !tipoEnderecoCob.isEmpty()) {
                enderecoCob.setTipoEndereco(TipoEndereco.fromDescricao(tipoEnderecoCob));
            }

            if (tipoEnderecoEnt != null && !tipoEnderecoEnt.isEmpty()) {
                enderecoEnt.setTipoEndereco(TipoEndereco.fromDescricao(tipoEnderecoEnt));
            }

            System.out.println("Endereco Residencial: " + enderecoRes);
            System.out.println("Endereco Cobranca: " + enderecoCob);
            System.out.println("Endereco Entrega: " + enderecoEnt);
            System.out.println("02 idCliente armazenado na sessão: " + cliente.getId());

            cliente.setEnderecoResidencial(enderecoRes);
            cliente.setEnderecoCobranca(enderecoCob);
            cliente.setEnderecoEntrega(enderecoEnt);

            IFachada fachada = new Fachada();
            System.out.println("03 idCliente armazenado na sessão: " + cliente.getId());
            String msgRes = fachada.salvarEndereco(enderecoRes);
            String msgCob = fachada.salvarEndereco(enderecoCob);
            String msgEnt = fachada.salvarEndereco(enderecoEnt);
            System.out.println("04 idCliente armazenado na sessão: " + cliente.getId());

            System.out.println("Resultado do salvar (Res): " + msgRes);
            System.out.println("Resultado do salvar (Cob): " + msgCob);
            System.out.println("Resultado do salvar (Ent): " + msgEnt);
            response.sendRedirect("index.jsp");
        } catch (Exception e) {
            throw new ServletException("Erro ao salvar endereço", e);
        }
    }

    private void salvarNovoEnderecoForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("adicionarNovoEndereco.jsp").forward(request, response);
    }

    private void salvarNovoEndereco(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Tentativa de obter o ID diretamente da requisição
            String idClienteParam = request.getParameter("idCliente");
            System.out.println("\nId do Cliente para Novo Endereco (via parâmetro): " + idClienteParam + "\n");

            HttpSession session = request.getSession(false);
            if (session != null) {
                // Recuperando o ID do cliente
                Integer clienteId = (Integer) session.getAttribute("clienteId");
                if (clienteId != null) {
                    System.out.println("ID do cliente recuperado da sessão: " + clienteId);
                } else {
                    System.out.println("ID do cliente não encontrado na sessão.");
                }
            } else {
                System.out.println("Sessão não encontrada.");
            }

            if (idClienteParam == null) {
                throw new ServletException("ID do cliente não encontrado.");
            }


            int idCliente = 0;
            try {
                idCliente = Integer.parseInt(idClienteParam);
            } catch (NumberFormatException e) {
                throw new ServletException("Formato inválido para o ID do cliente.", e);
            }

            ClienteDAO clienteDAO = new ClienteDAO();
            Cliente cliente = clienteDAO.consultarPorId(idCliente);
            if (cliente == null) {
                throw new ServletException("Cliente não encontrado.");
            }

            //Cliente cliente = new Cliente();
            cliente.setId(idCliente);

            String nomePaisNovoEnd = request.getParameter("nomePais_NovoEnd");
            System.out.println("SERVnomePais: " + nomePaisNovoEnd);
            String nomeEstadoNovoEnd = request.getParameter("nomeEstado_NovoEnd");
            System.out.println("nomeEstado: " + nomeEstadoNovoEnd);
            String nomeCidadeNovoEnd = request.getParameter("nomeCidade_NovoEnd");
            System.out.println("nomeCidade: " + nomeCidadeNovoEnd);
            String tipoLogradouroNovoEnd = request.getParameter("tipoLogradouro_NovoEnd");
            System.out.println("tipoLogradouro: " + tipoLogradouroNovoEnd);
            String tipoResidenciaNovoEnd = request.getParameter("tipoResidencia_NovoEnd");
            System.out.println("tipoResidencia: " + tipoResidenciaNovoEnd);
            String tipoEnderecoNovoEnd = request.getParameter("tipoEndereco_NovoEnd");
            System.out.println("tipoEndereco: " + tipoEnderecoNovoEnd);
            String cepNovoEnd = request.getParameter("cep_NovoEnd");
            System.out.println("cepRes: " + cepNovoEnd);
            String logradouroNovoEnd = request.getParameter("logradouro_NovoEnd");
            System.out.println("logradouro: " + logradouroNovoEnd);
            String numeroNovoEnd = request.getParameter("numero_NovoEnd");
            System.out.println("numero: " + numeroNovoEnd);
            String bairroNovoEnd = request.getParameter("bairro_NovoEnd");
            System.out.println("bairro: " + bairroNovoEnd);
            String observacaoNovoEnd = request.getParameter("observacao_NovoEnd");
            System.out.println("SERVobservacao: " + observacaoNovoEnd);

            Endereco enderecoNovoEnd = new Endereco();
            enderecoNovoEnd.setLogradouro(logradouroNovoEnd);
            enderecoNovoEnd.setNumero(numeroNovoEnd);
            enderecoNovoEnd.setBairro(bairroNovoEnd);
            enderecoNovoEnd.setCep(cepNovoEnd);
            enderecoNovoEnd.setObservacao(observacaoNovoEnd);
            if (tipoResidenciaNovoEnd == null || tipoResidenciaNovoEnd.isEmpty()) {
                throw new IllegalArgumentException("Nenhum tipo de residência selecionado.");
            } else {
                enderecoNovoEnd.setTipoResidencia(TipoResidencia.fromDescricao(tipoResidenciaNovoEnd));
            }
            enderecoNovoEnd.setTipoLogradouro(TipoLogradouro.fromDescricao(tipoLogradouroNovoEnd));
            enderecoNovoEnd.setTipoEndereco(TipoEndereco.fromDescricao(tipoEnderecoNovoEnd));

            Pais paisNovoEnd = new Pais();
            paisNovoEnd.setNome(nomePaisNovoEnd);

            Estado estadoNovoEnd = new Estado();
            estadoNovoEnd.setNome(nomeEstadoNovoEnd);
            estadoNovoEnd.setPais(paisNovoEnd);

            Cidade cidadeNovoEnd = new Cidade();
            cidadeNovoEnd.setNome(nomeCidadeNovoEnd);
            cidadeNovoEnd.setEstado(estadoNovoEnd);
            enderecoNovoEnd.setCidade(cidadeNovoEnd);

            Endereco enderecoNovo = new Endereco();
            enderecoNovo.setLogradouro(logradouroNovoEnd);
            enderecoNovo.setNumero(numeroNovoEnd);
            enderecoNovo.setBairro(bairroNovoEnd);
            enderecoNovo.setCep(cepNovoEnd);
            enderecoNovo.setCidade(cidadeNovoEnd);
            enderecoNovo.setObservacao(observacaoNovoEnd);
            enderecoNovo.setTipoResidencia(TipoResidencia.fromDescricao(tipoResidenciaNovoEnd));
            enderecoNovo.setTipoLogradouro(TipoLogradouro.fromDescricao(tipoLogradouroNovoEnd));
            enderecoNovo.setTipoEndereco(TipoEndereco.fromDescricao(tipoEnderecoNovoEnd));

            System.out.println("Endereco Novo: " + enderecoNovoEnd);
            System.out.println("02 idCliente armazenado na sessão: " + cliente.getId());

            cliente.setEndereco(enderecoNovoEnd);

            IFachada fachada = new Fachada();
            System.out.println("03 idCliente armazenado na sessão: " + cliente.getId());
            String msgNovoEnd = fachada.salvarEndereco(enderecoNovoEnd);
            System.out.println("04 idCliente armazenado na sessão: " + cliente.getId());

            System.out.println("Resultado do salvar (Res): " + msgNovoEnd);
            response.sendRedirect("consultarEndereco.jsp");

        } catch (Exception e) {
            throw new ServletException("Erro ao salvar endereço", e);
        }
    }

    private void excluirCliente(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");

        if (id != null) {
            System.out.println("Cliente com ID " + id + " excluído.");
        }

        response.sendRedirect("controller?action=consultar");
    }

    private void consultarProduto(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("produtoVenda.jsp").forward(request, response);
    }

    private void adicionarCarrinho(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("DEBUG: Entrou na servlet adicionarCarrinho");

        try {
            HttpSession session = request.getSession(false);
            if (session == null || session.getAttribute("clienteId") == null) {
                System.out.println("DEBUG: Sessão expirada ou cliente não logado");
                throw new ServletException("Sessão expirada ou cliente não logado.");
            }

            Integer clienteId = (Integer) session.getAttribute("clienteId");
            System.out.println("DEBUG: clienteId = " + clienteId);

            String idLivroParam = request.getParameter("idLivro");
            String quantidadeParam = request.getParameter("quantidade");

            if (idLivroParam == null || quantidadeParam == null) {
                System.out.println("DEBUG: Parâmetros ausentes: idLivroParam=" + idLivroParam + ", quantidadeParam=" + quantidadeParam);
                throw new ServletException("Parâmetros obrigatórios ausentes.");
            }

            int idLivro = Integer.parseInt(idLivroParam);
            int quantidade = Integer.parseInt(quantidadeParam);
            System.out.println("DEBUG: idItem = " + idLivro + ", quantidade = " + quantidade);

            Connection conn = null;
            try {
                conn = Conexao.createConnectionToMySQL();
                System.out.println("DEBUG: Conexão com banco estabelecida");

                CarrinhoDAO carrinhoDAO = new CarrinhoDAO();
                Carrinho carrinho = carrinhoDAO.buscarCarrinhoPorClienteId(clienteId, conn);
                int idCarrinho = carrinho.getId();
                System.out.println("DEBUG: idCarrinho = " + idCarrinho);

                CarrinhoItem carrinhoItem = new CarrinhoItem();
                carrinhoItem.setIdCarrinho(idCarrinho);
                carrinhoItem.setIdLivro(idLivro);
                carrinhoItem.setQuantidade(quantidade);

                CarrinhoItemDAO carrinhoItemDAO = new CarrinhoItemDAO();
                String msg = carrinhoItemDAO.salvar(carrinhoItem, conn);
                System.out.println("DEBUG: Resultado do salvar = " + msg);

                request.setAttribute("mensagem", msg);
            } catch (SQLException e) {
                System.out.println("DEBUG: SQLException - " + e.getMessage());
                throw new ServletException("Erro ao adicionar item ao carrinho", e);
            } finally {
                if (conn != null) try { conn.close(); System.out.println("DEBUG: Conexão fechada"); } catch (SQLException ignored) {}
            }

            request.getRequestDispatcher("produtoVenda.jsp").forward(request, response);
            System.out.println("DEBUG: Forward realizado para produtoVenda.jsp");

        } catch (Exception e) {
            System.out.println("DEBUG: Exceção capturada - " + e.getMessage());
            throw new ServletException("Erro ao adicionar item ao carrinho", e);
        }
    }

    private void removerItemCarrinho(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int itemId = Integer.parseInt(request.getParameter("id")); // agora usa o ID do item
            System.out.println("ID do item a excluir: " + itemId);
            int clienteId = (int) request.getSession().getAttribute("clienteId");

            CarrinhoItem item = new CarrinhoItem();
            item.setId(itemId);

            IFachada fachada = new Fachada();
            String resultado = fachada.excluir(item);

            if (resultado == null) {
                System.out.println("Item removido com sucesso.");
                request.getSession().setAttribute("mensagemSucesso", "Item removido com sucesso.");
            } else {
                System.out.println("Erro ao remover item: " + resultado);
                request.getSession().setAttribute("mensagemErro", resultado);
            }
        } catch (Exception e) {
            request.getSession().setAttribute("mensagemErro", "Erro ao remover item do carrinho.");
            e.printStackTrace();
        }
        response.sendRedirect("carrinho.jsp");
    }

    private void salvarPreviaPedido(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


        request.getRequestDispatcher("finalizarCompra.jsp").forward(request, response);
    }


}



