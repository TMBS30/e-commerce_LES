package controle;

public abstract class Ctrl {
    Fachada fachada = new Fachada();
}
