package dominio;

import java.util.List;

public class Venda {
    private int id;
    private double valorTotal;
    private List<Pagamento> pagamentos;
    private List<Cupom> cupons;
    private boolean cupomPromocional;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public List<Pagamento> getPagamentos() {
        return pagamentos;
    }

    public void setPagamentos(List<Pagamento> pagamentos) {
        this.pagamentos = pagamentos;
    }

    public List<Cupom> getCupons() {
        return cupons;
    }

    public void setCupons(List<Cupom> cupons) {
        this.cupons = cupons;
    }

    public boolean isCupomPromocional() {
        return cupomPromocional;
    }

    public void setCupomPromocional(boolean cupomPromocional) {
        this.cupomPromocional = cupomPromocional;
    }
}
